# Multi-Agent 协作系统

## 🚀 运行步骤

1. 安装依赖：
```
pip install -r requirements.txt
```

2. 设置 API Key：
```
export OPENAI_API_KEY=你的key
```
Windows:
```
set OPENAI_API_KEY=你的key
```

3. 运行：
```
python main.py
```

## 🧠 功能
- Planner：任务拆解
- Executor：执行任务
- Critic：结果评估

## 📌 示例任务
写一个Python猜数字游戏，并解释代码逻辑
