import os
from openai import OpenAI

client = OpenAI()

def call_llm(system_prompt, user_prompt):
    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        temperature=0.7
    )
    return response.choices[0].message.content

def planner(task):
    system_prompt = "你是一个任务规划专家，负责将复杂问题拆解成清晰步骤。"
    user_prompt = f"请将以下任务拆解为步骤（用1. 2. 3.列出）：

{task}"
    return call_llm(system_prompt, user_prompt)

def executor(plan):
    system_prompt = "你是一个执行专家，根据步骤完成任务。"
    user_prompt = f"请根据以下步骤执行任务，并给出详细结果：

{plan}"
    return call_llm(system_prompt, user_prompt)

def critic(task, result):
    system_prompt = "你是一个评估专家，负责判断结果是否满足需求，并提出改进建议。"
    user_prompt = f'''
任务：
{task}

执行结果：
{result}

请：
1. 判断是否完成任务（是/否）
2. 给出改进建议
'''
    return call_llm(system_prompt, user_prompt)

def run_multi_agent(task):
    print("🧠 Planner 正在拆解任务...")
    plan = planner(task)
    print("\n📋 任务步骤：\n", plan)

    print("\n⚙️ Executor 正在执行...")
    result = executor(plan)
    print("\n📊 执行结果：\n", result)

    print("\n✅ Critic 正在评估...")
    feedback = critic(task, result)
    print("\n📝 评估反馈：\n", feedback)

if __name__ == "__main__":
    task = input("请输入任务：")
    run_multi_agent(task)
